//
//  TaskView.swift
//  MyGarage
//
//  Created by Павел Магдыч on 22.04.2023.
//

import SwiftUI

struct TaskView: View {
    @State var isSelected: Bool = false
    
    var body: some View {
        VStack {
            Text("Task")
                .font(.title)
                .fontWeight(.light)
                .padding()
            
            if isSelected {
                Text("Addition Info")
                    .font(.footnote)
                    .fontWeight(.light)
                    
                HStack {
                    Text("Brand")
                        .font(.footnote)
                        .fontWeight(.light)
                    Text("Model")
                        .font(.footnote)
                        .fontWeight(.light)
                }.padding()
                
                Text("Service")
                    .font(.footnote)
                    .fontWeight(.light)
                    
                
                Text("Comment")
                    .font(.footnote)
                    .fontWeight(.light)
                    .padding()
                
            } else {
                Text("More")
                    .font(.footnote)
                    .fontWeight(.light)
            }
            
            RoundedRectangle(cornerRadius: 25)
                .fill(.black)
                .opacity(0.2)
                .frame(height: 6)
                .padding(.all)
        }
        .padding(.all)
        .onTapGesture {
            withAnimation(.easeInOut(duration: 0.6)) {
                isSelected.toggle()
            }
        }
    }
}

struct TaskView_Previews: PreviewProvider {
    static var previews: some View {
        TaskView()
    }
}
