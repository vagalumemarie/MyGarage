//
//  ProfileInfo.swift
//  MyGarage
//
//  Created by Павел Магдыч on 22.04.2023.
//

import Foundation

struct ProfileInfo: Identifiable, Codable {
    var id = UUID()
    var name: String
    var surname: String
    var email: String
    var brand: String
    var model: String
}
