//
//  ChatView.swift
//  MyGarage
//
//  Created by Павел Магдыч on 23.04.2023.
//

import SwiftUI

struct ChatView: View {
    @State var messageText = ""
    
    var myMessages = ["Hi, yes", "I would like to know the price of an oil change in my car"]
    var responceMessages = ["Hi, can I help you with something?"]
    
    var body: some View {
        VStack {
            ScrollView(showsIndicators: false) {
                ResponceMessageView(message: responceMessages[0])
                MyMessageView(message: myMessages[0])
                MyMessageView(message: myMessages[1])
                Spacer()
 
            }
            
            HStack {
                Button {
                    
                } label: {
                    ZStack {
                        Circle()
                            .fill(DrawingConstants.backgroundLight)
                            .frame(width: 60, height: 60)
                            .shadow(color: DrawingConstants.shadowColor, radius: 6, y: 6)
                        
                        Image(systemName: "paperplane.fill")
                            .foregroundColor(DrawingConstants.shadowColor)
                    }
                }
                
                TextField("Enter message", text: $messageText)
                    .padding()
                    .fontWeight(.light)
                    .foregroundColor(.black)
                    .background(
                        RoundedRectangle(cornerRadius: 10)
                            .fill(DrawingConstants.backgroundLight)
                            .shadow(color: DrawingConstants.shadowColor, radius: 6, x: 0, y: 6)
                    )
                    .padding()
            }
            
            Spacer()
                .frame(height: 100)
            
        }
    }
    
    struct MyMessageView: View {
        var message: String
        var body: some View {
            HStack {
                Spacer()
                ZStack(alignment: .leading) {
                    RoundedRectangle(cornerRadius: 25)
                        .fill(DrawingConstants.backgroundDark)
                    
                    
                    Text(message)
                        .font(.headline)
                        .fontWeight(.light)
                        .foregroundColor(.black)
                        .padding()
                }
                .frame(width: 300, alignment: .leading)
                
            }
        }
    }
    
    struct ResponceMessageView: View {
        var message: String
        var body: some View {
            HStack {
                ZStack(alignment: .leading) {
                    RoundedRectangle(cornerRadius: 25)
                        .fill(DrawingConstants.shadowColor)
                    
                    
                    Text(message)
                        .font(.headline)
                        .fontWeight(.light)
                        .foregroundColor(.black)
                        .padding()
                }
                .frame(width: 300, alignment: .trailing)
                
                Spacer()
            }
        }
    }
}


struct ChatView_Previews: PreviewProvider {
    static var previews: some View {
        ChatView()
    }
}
