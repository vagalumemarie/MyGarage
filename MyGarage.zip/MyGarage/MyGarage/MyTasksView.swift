//
//  MyTasksView.swift
//  MyGarage
//
//  Created by Павел Магдыч on 22.04.2023.
//

import SwiftUI

struct MyTasksView: View {
    @State var isMyTasksShow: Bool = false
    @State var isFullSize: Bool = false
    
    var body: some View {
        ZStack {
            RoundedRectangle(cornerRadius: 25)
                .fill(
                    LinearGradient(colors: [DrawingConstants.myTasksDark, DrawingConstants.myTasksLight], startPoint: .bottomTrailing, endPoint: .topLeading)
                )
            
            VStack {
                Text("My Requests")
                    .font(.largeTitle)
                    .fontWeight(.thin)
                    .padding(.all)
                
                if isMyTasksShow {
                    ScrollView {
                        TaskView()
                        TaskView()
                        TaskView()
                    }
                }
            }
        }
        .ignoresSafeArea()
        .frame(height: isFullSize ? 500 : 80)
        .shadow(color: DrawingConstants.shadowColor, radius: 40)
        .onTapGesture {
            withAnimation(.easeInOut(duration: 0.2)) {
                isMyTasksShow.toggle()
            }
            withAnimation(.easeInOut(duration: 0.6)) {
                isFullSize.toggle()
            }
        }
    }
}

struct MyTasksView_Previews: PreviewProvider {
    static var previews: some View {
        MyTasksView()
    }
}
