//
//  RegistrationFormView.swift
//  MyGarage
//
//  Created by Павел Магдыч on 23.04.2023.
//

import SwiftUI

struct RegistrationFormView: View {
    @State var isUserHaveAccount: Bool = true
    @State var surnameText = ""
    @State var nameText = ""
    @State var emailText = ""
    @State var passwordText = ""
    
    @State var loginEmailText = ""
    @State var loginPasswordText = ""
    
    var body: some View {
        VStack {
            if isUserHaveAccount {
                HStack {
                    Text("Log in")
                        .font(.largeTitle)
                        .fontWeight(.thin)
                        .padding(.all)
                    
                    Spacer()
                    
                    Button {
                        withAnimation(.easeInOut(duration: 0.6)) {
                            isUserHaveAccount.toggle()
                        }
                    } label: {
                        Text("Don't Have\nAccount?")
                            .fontWeight(.light)
                            .foregroundColor(.black)
                            .padding(.horizontal)
                    }
                }
                
                HStack {
                    Text("Email")
                        .fontWeight(.light)
                        .foregroundColor(.black)
                        .padding(.horizontal)
                        .frame(width: 130)
                    
                    TextField("Enter email", text: $loginEmailText)
                        .padding()
                        .fontWeight(.light)
                        .foregroundColor(.black)
                        .background(
                            RoundedRectangle(cornerRadius: 10)
                                .fill(DrawingConstants.backgroundDark)
                                .shadow(color: DrawingConstants.shadowColor, radius: 6, x: 0, y: 6)
                        )
                        .padding()
                }
                
                HStack {
                    Text("Password")
                        .fontWeight(.light)
                        .foregroundColor(.black)
                        .padding(.horizontal)
                        .frame(width: 130)
                    
                    SecureField("Enter password", text: $loginPasswordText)
                        .padding()
                        .fontWeight(.light)
                        .foregroundColor(.black)
                        .background(
                            RoundedRectangle(cornerRadius: 10)
                                .fill(DrawingConstants.backgroundDark)
                                .shadow(color: DrawingConstants.shadowColor, radius: 6, x: 0, y: 6)
                        )
                        .padding()
                    
                }
                Button {
                    
                } label: {
                    Text("Submit")
                        .font(.title2)
                        .fontWeight(.light)
                        .foregroundColor(.black)
                        .padding(.all)
                }
                
                
            } else {
                HStack {
                    Text("Registration")
                        .font(.largeTitle)
                        .fontWeight(.thin)
                        .padding(.all)
                    
                    Spacer()
                    
                    Button {
                        withAnimation(.easeInOut(duration: 0.6)) {
                            isUserHaveAccount.toggle()
                        }
                    } label: {
                        Text("Have\nAccount?")
                            .fontWeight(.light)
                            .foregroundColor(.black)
                            .padding(.horizontal)
                    }
                }
                
                HStack {
                    Text("Surname")
                        .fontWeight(.light)
                        .foregroundColor(.black)
                        .padding(.horizontal)
                        .frame(width: 130)
                    
                    TextField("Enter surname", text: $surnameText)
                        .padding()
                        .fontWeight(.light)
                        .foregroundColor(.black)
                        .background(
                            RoundedRectangle(cornerRadius: 10)
                                .fill(DrawingConstants.backgroundDark)
                                .shadow(color: DrawingConstants.shadowColor, radius: 6, x: 0, y: 6)
                        )
                        .padding()
                }
                HStack {
                    Text("Name")
                        .fontWeight(.light)
                        .foregroundColor(.black)
                        .padding(.horizontal)
                        .frame(width: 130)
                    
                    TextField("Enter name", text: $nameText)
                        .padding()
                        .fontWeight(.light)
                        .foregroundColor(.black)
                        .background(
                            RoundedRectangle(cornerRadius: 10)
                                .fill(DrawingConstants.backgroundDark)
                                .shadow(color: DrawingConstants.shadowColor, radius: 6, x: 0, y: 6)
                        )
                        .padding()
                }
                
                HStack {
                    Text("Email")
                        .fontWeight(.light)
                        .foregroundColor(.black)
                        .padding(.horizontal)
                        .frame(width: 130)
                    
                    TextField("Enter email", text: $emailText)
                        .padding()
                        .fontWeight(.light)
                        .foregroundColor(.black)
                        .background(
                            RoundedRectangle(cornerRadius: 10)
                                .fill(DrawingConstants.backgroundDark)
                                .shadow(color: DrawingConstants.shadowColor, radius: 6, x: 0, y: 6)
                        )
                        .padding()
                    
                }
                
                HStack {
                    Text("Password")
                        .fontWeight(.light)
                        .foregroundColor(.black)
                        .padding(.horizontal)
                        .frame(width: 130)
                    
                    SecureField("Enter password", text: $passwordText)
                        .padding()
                        .fontWeight(.light)
                        .foregroundColor(.black)
                        .background(
                            RoundedRectangle(cornerRadius: 10)
                                .fill(DrawingConstants.backgroundDark)
                                .shadow(color: DrawingConstants.shadowColor, radius: 6, x: 0, y: 6)
                        )
                        .padding()
                    
                }
                Button {
                    
                } label: {
                    Text("Submit")
                        .font(.title2)
                        .fontWeight(.light)
                        .foregroundColor(.black)
                        .padding(.all)
                }
                
            }
        }
    }
}

struct RegistrationFormView_Previews: PreviewProvider {
    static var previews: some View {
        RegistrationFormView()
    }
}
