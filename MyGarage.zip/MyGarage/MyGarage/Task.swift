//
//  Task.swift
//  MyGarage
//
//  Created by Павел Магдыч on 22.04.2023.
//

import Foundation

struct Task: Identifiable, Codable {
    var id = UUID()
    var title: String
    var service: String
    var comment: String
    var data: Int
}
