//
//  MyGarageApp.swift
//  MyGarage
//
//  Created by Павел Магдыч on 22.04.2023.
//

import SwiftUI

@main
struct MyGarageApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
