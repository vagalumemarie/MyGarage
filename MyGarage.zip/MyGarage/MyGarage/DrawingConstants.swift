//
//  DrawingConstants.swift
//  MyGarage
//
//  Created by Павел Магдыч on 22.04.2023.
//

import SwiftUI

struct DrawingConstants {
    static let backgroundDark = Color(red: 0.73, green: 0.73, blue: 0.92)
    static let backgroundLight = Color(red: 0.96, green: 0.88, blue: 0.96)
    
    static let myTasksDark = Color(red: 0.73, green: 0.73, blue: 0.92)
    static let myTasksLight = Color(red: 0.96, green: 0.88, blue: 0.96)
    
    static let shadowColor = Color(red: 0.6, green: 0.6, blue: 0.8)
}
