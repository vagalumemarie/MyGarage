//
//  ProfileInfoView.swift
//  MyGarage
//
//  Created by Павел Магдыч on 23.04.2023.
//

import SwiftUI

struct ProfileInfoView: View {
    @Binding var profileInfo: ProfileInfo
    
    var body: some View {
        VStack {
            
            Text("Surname: \(profileInfo.surname)")
                .font(.headline)
                .fontWeight(.light)
                .foregroundColor(.black)
                .padding()
            
            Text("Name: \(profileInfo.name)")
                .font(.headline)
                .fontWeight(.light)
                .foregroundColor(.black)
                .padding()
            
            Text("Email: \(profileInfo.email)")
                .font(.headline)
                .fontWeight(.light)
                .foregroundColor(.black)
                .padding()
            
            Spacer()
            
            Button {
                
            } label: {
                Text("Change password")
                    .font(.title3)
                    .fontWeight(.light)
                    .foregroundColor(.black)
                    .padding()
            }
            
            Button {
                
            } label: {
                Text("Exit")
                    .font(.title3)
                    .fontWeight(.light)
                    .foregroundColor(.black)
                    .padding()
            }
            
            Spacer().frame(height: 150)
        }
            
    }
}

struct ProfileInfoView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
