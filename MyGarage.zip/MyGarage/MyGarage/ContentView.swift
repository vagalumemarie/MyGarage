//
//  ContentView.swift
//  MyGarage
//
//  Created by Павел Магдыч on 22.04.2023.
//

import SwiftUI

struct ContentView: View {
    @State var isUserRegistered: Bool = true
    @State var tasks = [Task]()
    @State var profileInfo: ProfileInfo = ProfileInfo(name: "Ivan", surname: "Ivanov", email: "ivanov@gmail.com", brand: "Maserati", model: "Levante")
    
    @State private var selectedButtonIndex = 0
    let buttons = ["plus", "car", "person", "message"]
    
    
    var body: some View {
        ZStack {
            if isUserRegistered {
                let views = [
                    AnyView(AddTaskView().padding(.all)),
                    AnyView(CarInfoView(profileInfo: $profileInfo).padding(.all)),
                    AnyView(ProfileInfoView(profileInfo: $profileInfo).padding(.all)),
                    AnyView(ChatView().padding(.all))
                ]
                
                
                LinearGradient(colors: [DrawingConstants.backgroundDark, DrawingConstants.backgroundLight], startPoint: .bottom, endPoint: .top)
                    .ignoresSafeArea()
                
                VStack {
                    Text("MyGarage")
                        .font(.largeTitle)
                        .fontWeight(.thin)
                        .padding(.all)
                    
                    HStack(spacing: 20) {
                        ForEach(0..<buttons.count) { index in
                            Button(action: {
                                withAnimation(.spring()) {
                                    self.selectedButtonIndex = index
                                }
                            }) {
                                ZStack {
                                    if selectedButtonIndex == index  {
                                        ZStack {
                                            Circle()
                                                .fill(DrawingConstants.backgroundDark)
                                                .frame(width: 60, height: 60)
                                            
                                            Circle()
                                                .fill(DrawingConstants.backgroundDark)
                                                .frame(width: 60, height: 60)
                                                .overlay(
                                                    Circle()
                                                        .stroke(Color.black.opacity(0.2), lineWidth: 4)
                                                        .blur(radius: 4)
                                                        .offset(x: -2, y: -2)
                                                        .mask(Circle()
                                                            .fill(
                                                                LinearGradient(
                                                                    gradient: Gradient(colors: [.black, .clear]),
                                                                    startPoint: .center,
                                                                    endPoint: .bottom
                                                                )
                                                            )
                                                              
                                                        )
                                                    
                                                    
                                                )
                                                .clipShape(Circle().inset(by: 4))
                                                .shadow(color: Color.black.opacity(0.2), radius: 5, x: 2, y: 2)
                                                .blur(radius: 2)
                                            Image(systemName: buttons[index])
                                                .foregroundColor(DrawingConstants.backgroundLight)
                                        }
                                        
                                    } else {
                                        Circle()
                                            .fill(DrawingConstants.backgroundLight)
                                            .frame(width: 60, height: 60)
                                            .shadow(color: DrawingConstants.shadowColor, radius: 6, y: 6)
                                        
                                        Image(systemName: buttons[index])
                                            .foregroundColor(DrawingConstants.shadowColor)
                                    }
                                }
                            }
                        }
                    }
                    
                    views[selectedButtonIndex]
                    
                    Spacer()
                    
                }
                VStack {
                    Spacer()
                    MyTasksView()
                }
            } else {
                ZStack {
                    LinearGradient(colors: [DrawingConstants.backgroundDark, DrawingConstants.backgroundLight], startPoint: .bottom, endPoint: .top)
                        .ignoresSafeArea()
                    RegistrationFormView().padding(.all)
                }
            }
        }
        .onAppear {
           
        }
    }
}


struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
