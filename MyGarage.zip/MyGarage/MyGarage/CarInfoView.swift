//
//  CarInfoView.swift
//  MyGarage
//
//  Created by Павел Магдыч on 22.04.2023.
//

import SwiftUI

struct CarInfoView: View {
    @Binding var profileInfo: ProfileInfo
    var body: some View {
        VStack {
            HStack {
                Text("Brand: \(profileInfo.brand)")
                    .font(.headline)
                    .fontWeight(.light)
                    .foregroundColor(.black)
                    .padding()
                
                Text("Model: \(profileInfo.model)")
                    .font(.headline)
                    .fontWeight(.light)
                    .foregroundColor(.black)
                    .padding()
            }
            
            Text("History")
                .font(.title)
                .fontWeight(.light)
                .padding(.all)
            Text("History is empty")
                .font(.footnote)
                .fontWeight(.light)
            
            Spacer()
        }
    }
}

struct CarInfoView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
