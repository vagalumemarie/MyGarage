//
//  AddTaskView.swift
//  MyGarage
//
//  Created by Павел Магдыч on 22.04.2023.
//

import SwiftUI

struct AddTaskView: View {
    @State var titleText = ""
    @State var commentText = ""
    @State private var selectedService = "Spare parts"
    
    let services = ["Maintenance", "Repair", "Oil Change", "Spare parts", "Diagnostics", "Tire fitting", "Other"]
        
    var body: some View {
        ScrollView(showsIndicators: false) {
            VStack(alignment: .leading) {
                Text("Request title")
                    .fontWeight(.light)
                    .foregroundColor(.black)
                    .padding(.horizontal)
                
                TextField("Enter title", text: $titleText)
                    .padding()
                    .fontWeight(.light)
                    .foregroundColor(.black)
                    .background(
                        RoundedRectangle(cornerRadius: 10)
                            .fill(DrawingConstants.backgroundDark)
                            .shadow(color: DrawingConstants.shadowColor, radius: 6, x: 0, y: 6)
                    )
                    .padding()
                
                Text("Service: \(selectedService)")
                    .fontWeight(.light)
                    .foregroundColor(.black)
                    .padding([.leading, .bottom, .trailing])
                
                ZStack {
                    RoundedRectangle(cornerRadius: 25)
                        .fill(DrawingConstants.backgroundDark)
                        .shadow(color: DrawingConstants.shadowColor, radius: 6, x: 0, y: 6)
                    
                    
                    Picker("Services", selection: $selectedService) {
                        ForEach(services, id: \.self) { service in
                            Text(service).fontWeight(.light).tag(service)
                        }
                    }
                    .pickerStyle(WheelPickerStyle())
                }
                .frame(height: 150)
                .padding(.horizontal)
                
                Text("Request Comment")
                    .fontWeight(.light)
                    .foregroundColor(.black)
                    .padding([.top, .leading, .trailing])
                
                TextField("Enter comment", text: $commentText)
                    .padding()
                    .fontWeight(.light)
                    .foregroundColor(.black)
                    .background(
                        RoundedRectangle(cornerRadius: 10)
                            .fill(DrawingConstants.backgroundDark)
                            .shadow(color: DrawingConstants.shadowColor, radius: 6, x: 0, y: 6)
                    )
                    .padding()
            }
            VStack {
                Button {
                    
                } label: {
                    Text("Submit")
                        .font(.title2)
                        .fontWeight(.light)
                        .foregroundColor(.black)
                }
                
                Spacer()
                    .frame(height: 100)
            }
        }
    }
}

struct AddTaskView_Previews: PreviewProvider {
    static var previews: some View {
        AddTaskView()
    }
}
